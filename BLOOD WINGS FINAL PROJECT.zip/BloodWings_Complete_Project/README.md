# Blood Wings — Complete local project

A student-project prototype with account registration/login, phone/email identifier, mandatory provider-delivered OTP, SQLite persistence, donor availability, blood requests, OpenStreetMap search/map, delivery records, browser geolocation sharing, acknowledgement records and history.

## Run on Windows
1. Extract this folder to a normal local folder.
2. Open the **BloodWings_Complete_Project** folder in VS Code (the folder containing `server.js` and `package.json`).
3. Open Terminal → New Terminal and run:

   ```cmd
   npm install
   npm start
   ```
4. Open `http://localhost:3000` in your browser.

If port 3000 is already in use, stop the old server terminal with `Ctrl+C` first. Do not kill random processes. Alternatively set `PORT=3001` in `.env` and use `http://localhost:3001`.

## Accounts and saved data
- SQLite database: `data/bloodwings.sqlite`. It persists after logout/restart.
- Register once, then use the same email/phone and password to return to that account and its history.
- To keep your previous account and saved history: before the first start, copy `data\bloodwings.sqlite` from your currently working `BloodWings_Complete_Fresh` folder into this project’s `data` folder. Keep a backup first. This version detects and migrates the previous starter schema automatically. If you do not copy the database, this will be a new empty database, so your old account/history will not appear.
- Email and phone are alternate login identifiers. To register with phone only, leave the email identifier field as a phone number; enter the phone number in the separate phone field too.
- OTP is mandatory after password validation. Email OTP uses SMTP settings in `.env`; SMS OTP uses Twilio settings in `.env`. You must provide your own provider credentials before either delivery channel can send codes. This project intentionally does not print OTP codes in the terminal or bypass verification when providers are missing.

## Maps and location
- Uses Leaflet and OpenStreetMap map tiles, with public Nominatim geocoding for user-triggered hospital/address searches.
- Internet access is needed for map tiles and geocoding. Nominatim is a public shared service subject to usage policy; don't run bulk searches.
- Browser geolocation requires user permission and usually a secure context (localhost is allowed). The delivery agent must explicitly start sharing and keep the page open. Tracking is a prototype, not guaranteed continuous background tracking.
- A mapped hospital result is not proof that a hospital has blood available or offers a particular service. Confirm directly with the hospital.

## Important safety and deployment notes
- Use dummy/test data until the project is security-reviewed. Blood group, contact details and location are sensitive personal data.
- The app is not a medical service and does not verify donor suitability. A hospital/blood bank must confirm compatibility, stock, collection, storage and transport.
- Acknowledgement printouts are project-generated records, not official medical or legal certificates.
- This local project has no production SMS/email OTP, HTTPS deployment, verified donor workflow, administrator review, or external cloud database. Do not deploy it publicly with real patient data without those safeguards.

## Font
The UI uses Times New Roman throughout, as requested.

## OTP provider setup
Copy `.env.example` to `.env`. Configure SMTP credentials for email OTP and Twilio credentials for SMS OTP. The app cannot send email or SMS without valid credentials from the relevant provider. Do not share provider passwords or commit `.env`. Generate a private JWT secret for local use.
